Ajax add to Cart
===============
Ajax add to Cart is a Drupal 8 Commerce's extension that is used to add
product into cart using Ajax.

This module Ajaxify the add to cart process. A pop up message is instantly 
generated as the item is added to the cart and cart items will also be updated 
if cart block is placed in any region.

Features:
Pop-up message will appear instantly if cart block is placed in any region.
Pop-up message & cart items will appear instantly if cart block is 
not placed in any region.
