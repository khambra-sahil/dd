<?php

namespace Drupal\commerce_exchanger\Exception;

/**
 * Thrown when trying to deal with invalid data structure.
 */
class ExchangeRatesDataMismatchException extends \InvalidArgumentException {}
